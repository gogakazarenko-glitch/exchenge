import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface TelegramUpdate {
  message?: {
    chat: {
      id: number;
      first_name?: string;
      last_name?: string;
      username?: string;
    };
    from: {
      id: number;
      first_name?: string;
      last_name?: string;
      username?: string;
    };
    text?: string;
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const update: TelegramUpdate = await req.json();

    if (!update.message?.text) {
      return new Response(JSON.stringify({ ok: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { message } = update;
    const chatId = message.chat.id;
    const text = message.text;
    const userId = message.from.id;

    let responseText = '';

    if (text === '/start') {
      const { data: existingUser } = await supabase
        .from('users')
        .select('*')
        .eq('telegram_id', userId)
        .maybeSingle();

      if (!existingUser) {
        const { error: userError } = await supabase
          .from('users')
          .insert({
            telegram_id: userId,
            username: message.from.username,
            first_name: message.from.first_name,
            last_name: message.from.last_name,
          });

        if (userError) {
          console.error('Error creating user:', userError);
        }

        const walletAddress = `0x${Math.random().toString(16).substr(2, 40)}`;
        const { data: userData } = await supabase
          .from('users')
          .select('id')
          .eq('telegram_id', userId)
          .single();

        if (userData) {
          await supabase.from('wallets').insert([
            { user_id: userData.id, currency: 'BTC', balance: 0.5, address: walletAddress },
            { user_id: userData.id, currency: 'ETH', balance: 2.3, address: walletAddress },
            { user_id: userData.id, currency: 'USDT', balance: 1000, address: walletAddress },
          ]);
        }

        responseText = `✅ Добро пожаловать в Крипто Кошелёк!\n\nВаш кошелёк успешно создан.\n\nДоступные команды:\n/balance - Показать баланс\n/wallets - Список кошельков\n/transactions - История транзакций\n\n🌐 Откройте веб-интерфейс для полного доступа`;
      } else {
        responseText = `👋 С возвращением!\n\nДоступные команды:\n/balance - Показать баланс\n/wallets - Список кошельков\n/transactions - История транзакций`;
      }
    } else if (text === '/balance') {
      const { data: userData } = await supabase
        .from('users')
        .select('id')
        .eq('telegram_id', userId)
        .maybeSingle();

      if (userData) {
        const { data: wallets } = await supabase
          .from('wallets')
          .select('*')
          .eq('user_id', userData.id);

        if (wallets && wallets.length > 0) {
          responseText = '💰 Ваш баланс:\n\n';
          wallets.forEach((wallet: any) => {
            responseText += `${wallet.currency}: ${wallet.balance}\n`;
          });
        } else {
          responseText = 'У вас пока нет кошельков';
        }
      } else {
        responseText = 'Сначала используйте команду /start';
      }
    } else if (text === '/wallets') {
      const { data: userData } = await supabase
        .from('users')
        .select('id')
        .eq('telegram_id', userId)
        .maybeSingle();

      if (userData) {
        const { data: wallets } = await supabase
          .from('wallets')
          .select('*')
          .eq('user_id', userData.id);

        if (wallets && wallets.length > 0) {
          responseText = '👛 Ваши кошельки:\n\n';
          wallets.forEach((wallet: any) => {
            responseText += `${wallet.currency}\n`;
            responseText += `Баланс: ${wallet.balance}\n`;
            responseText += `Адрес: ${wallet.address.substring(0, 10)}...\n\n`;
          });
        } else {
          responseText = 'У вас пока нет кошельков';
        }
      } else {
        responseText = 'Сначала используйте команду /start';
      }
    } else if (text === '/transactions') {
      const { data: userData } = await supabase
        .from('users')
        .select('id')
        .eq('telegram_id', userId)
        .maybeSingle();

      if (userData) {
        const { data: wallets } = await supabase
          .from('wallets')
          .select('id')
          .eq('user_id', userData.id);

        if (wallets && wallets.length > 0) {
          const walletIds = wallets.map((w: any) => w.id);
          const { data: transactions } = await supabase
            .from('transactions')
            .select('*')
            .in('wallet_id', walletIds)
            .order('created_at', { ascending: false })
            .limit(10);

          if (transactions && transactions.length > 0) {
            responseText = '📋 Последние транзакции:\n\n';
            transactions.forEach((tx: any) => {
              responseText += `${tx.type.toUpperCase()}: ${tx.amount} ${tx.currency}\n`;
              responseText += `Статус: ${tx.status}\n`;
              responseText += `Дата: ${new Date(tx.created_at).toLocaleString()}\n\n`;
            });
          } else {
            responseText = 'У вас пока нет транзакций';
          }
        }
      } else {
        responseText = 'Сначала используйте команду /start';
      }
    } else {
      responseText = 'Неизвестная команда. Используйте:\n/start - Начать\n/balance - Баланс\n/wallets - Кошельки\n/transactions - Транзакции';
    }

    await fetch(`https://api.telegram.org/bot${Deno.env.get('TELEGRAM_BOT_TOKEN')}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: responseText,
      }),
    });

    return new Response(JSON.stringify({ ok: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
