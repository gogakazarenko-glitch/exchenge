/*
  # Create Crypto Wallet Schema

  1. New Tables
    - `users`
      - `id` (uuid, primary key) - Internal user ID
      - `telegram_id` (bigint, unique) - Telegram user ID
      - `username` (text) - Telegram username
      - `first_name` (text) - User's first name
      - `last_name` (text) - User's last name
      - `created_at` (timestamptz) - Account creation timestamp
      - `last_active` (timestamptz) - Last activity timestamp
    
    - `wallets`
      - `id` (uuid, primary key) - Wallet ID
      - `user_id` (uuid, foreign key) - Owner of the wallet
      - `currency` (text) - Cryptocurrency type (BTC, ETH, USDT, etc.)
      - `balance` (numeric) - Current balance
      - `address` (text) - Wallet address (simulated)
      - `created_at` (timestamptz) - Wallet creation timestamp
    
    - `transactions`
      - `id` (uuid, primary key) - Transaction ID
      - `wallet_id` (uuid, foreign key) - Associated wallet
      - `type` (text) - Transaction type (send, receive, exchange)
      - `amount` (numeric) - Transaction amount
      - `currency` (text) - Currency of transaction
      - `to_address` (text) - Recipient address
      - `from_address` (text) - Sender address
      - `status` (text) - Transaction status (pending, completed, failed)
      - `created_at` (timestamptz) - Transaction timestamp
      - `completed_at` (timestamptz) - Completion timestamp

  2. Security
    - Enable RLS on all tables
    - Users can only access their own data
    - Authenticated users can view their wallets and transactions
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  telegram_id bigint UNIQUE NOT NULL,
  username text,
  first_name text,
  last_name text,
  created_at timestamptz DEFAULT now(),
  last_active timestamptz DEFAULT now()
);

-- Create wallets table
CREATE TABLE IF NOT EXISTS wallets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  currency text NOT NULL,
  balance numeric DEFAULT 0,
  address text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create transactions table
CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id uuid REFERENCES wallets(id) ON DELETE CASCADE NOT NULL,
  type text NOT NULL,
  amount numeric NOT NULL,
  currency text NOT NULL,
  to_address text,
  from_address text,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for users table
CREATE POLICY "Users can view own profile"
  ON users FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON users FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- RLS Policies for wallets table
CREATE POLICY "Users can view own wallets"
  ON wallets FOR SELECT
  TO authenticated
  USING (
    user_id IN (
      SELECT id FROM users WHERE auth.uid() = id
    )
  );

CREATE POLICY "Users can insert own wallets"
  ON wallets FOR INSERT
  TO authenticated
  WITH CHECK (
    user_id IN (
      SELECT id FROM users WHERE auth.uid() = id
    )
  );

CREATE POLICY "Users can update own wallets"
  ON wallets FOR UPDATE
  TO authenticated
  USING (
    user_id IN (
      SELECT id FROM users WHERE auth.uid() = id
    )
  )
  WITH CHECK (
    user_id IN (
      SELECT id FROM users WHERE auth.uid() = id
    )
  );

-- RLS Policies for transactions table
CREATE POLICY "Users can view own transactions"
  ON transactions FOR SELECT
  TO authenticated
  USING (
    wallet_id IN (
      SELECT w.id FROM wallets w
      INNER JOIN users u ON w.user_id = u.id
      WHERE auth.uid() = u.id
    )
  );

CREATE POLICY "Users can insert own transactions"
  ON transactions FOR INSERT
  TO authenticated
  WITH CHECK (
    wallet_id IN (
      SELECT w.id FROM wallets w
      INNER JOIN users u ON w.user_id = u.id
      WHERE auth.uid() = u.id
    )
  );

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_users_telegram_id ON users(telegram_id);
CREATE INDEX IF NOT EXISTS idx_wallets_user_id ON wallets(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_wallet_id ON transactions(wallet_id);
CREATE INDEX IF NOT EXISTS idx_transactions_created_at ON transactions(created_at DESC);