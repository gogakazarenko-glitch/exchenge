import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface User {
  id: string;
  telegram_id: number;
  username: string | null;
  first_name: string | null;
  last_name: string | null;
  created_at: string;
  last_active: string;
}

export interface Wallet {
  id: string;
  user_id: string;
  currency: string;
  balance: number;
  address: string;
  created_at: string;
}

export interface Transaction {
  id: string;
  wallet_id: string;
  type: string;
  amount: number;
  currency: string;
  to_address: string | null;
  from_address: string | null;
  status: string;
  created_at: string;
  completed_at: string | null;
}
