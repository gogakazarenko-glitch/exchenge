import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { Wallet, ArrowUpRight, ArrowDownLeft, LogOut, Send, QrCode, Clock } from 'lucide-react';
import type { Wallet as WalletType, Transaction } from '../lib/supabase';
import SendModal from './SendModal';
import TransactionHistory from './TransactionHistory';

export default function WalletDashboard() {
  const { user, signOut } = useAuth();
  const [wallets, setWallets] = useState<WalletType[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [showSendModal, setShowSendModal] = useState(false);
  const [selectedWallet, setSelectedWallet] = useState<WalletType | null>(null);

  useEffect(() => {
    loadData();
  }, [user]);

  const loadData = async () => {
    if (!user) return;

    try {
      const { data: walletsData } = await supabase
        .from('wallets')
        .select('*')
        .order('currency');

      const { data: transactionsData } = await supabase
        .from('transactions')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);

      setWallets(walletsData || []);
      setTransactions(transactionsData || []);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const totalValue = wallets.reduce((sum, wallet) => {
    const rates: Record<string, number> = { BTC: 50000, ETH: 3000, USDT: 1 };
    return sum + (wallet.balance * (rates[wallet.currency] || 1));
  }, 0);

  const getCurrencyIcon = (currency: string) => {
    const icons: Record<string, string> = {
      BTC: '₿',
      ETH: 'Ξ',
      USDT: '₮'
    };
    return icons[currency] || '💰';
  };

  const handleSend = (wallet: WalletType) => {
    setSelectedWallet(wallet);
    setShowSendModal(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 flex items-center justify-center">
        <div className="text-xl text-gray-600">Загрузка...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-r from-blue-500 to-cyan-500 p-2 rounded-lg">
              <Wallet className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Крипто Кошелёк</h1>
          </div>
          <button
            onClick={signOut}
            className="flex items-center space-x-2 px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition"
          >
            <LogOut className="w-5 h-5" />
            <span>Выйти</span>
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl p-8 text-white mb-8 shadow-xl">
          <p className="text-blue-100 mb-2">Общий баланс</p>
          <h2 className="text-4xl font-bold mb-6">${totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h2>
          <div className="flex space-x-4">
            <button className="flex items-center space-x-2 bg-white text-blue-600 px-6 py-3 rounded-xl font-semibold hover:bg-blue-50 transition shadow-lg">
              <ArrowDownLeft className="w-5 h-5" />
              <span>Получить</span>
            </button>
            <button className="flex items-center space-x-2 bg-white/20 backdrop-blur text-white px-6 py-3 rounded-xl font-semibold hover:bg-white/30 transition">
              <QrCode className="w-5 h-5" />
              <span>QR Код</span>
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-xl font-bold text-gray-800 mb-4">Мои Кошельки</h3>
            <div className="space-y-4">
              {wallets.map((wallet) => (
                <div
                  key={wallet.id}
                  className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl hover:shadow-md transition"
                >
                  <div className="flex items-center space-x-4">
                    <div className="bg-gradient-to-r from-blue-500 to-cyan-500 w-12 h-12 rounded-xl flex items-center justify-center text-white text-2xl font-bold">
                      {getCurrencyIcon(wallet.currency)}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">{wallet.currency}</p>
                      <p className="text-sm text-gray-500">
                        {wallet.address.substring(0, 10)}...
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-gray-800">{wallet.balance}</p>
                    <button
                      onClick={() => handleSend(wallet)}
                      className="mt-2 flex items-center space-x-1 text-blue-600 hover:text-blue-700 text-sm font-medium"
                    >
                      <Send className="w-4 h-4" />
                      <span>Отправить</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <TransactionHistory transactions={transactions} />
        </div>
      </main>

      {showSendModal && selectedWallet && (
        <SendModal
          wallet={selectedWallet}
          onClose={() => {
            setShowSendModal(false);
            setSelectedWallet(null);
          }}
          onSuccess={() => {
            loadData();
            setShowSendModal(false);
            setSelectedWallet(null);
          }}
        />
      )}
    </div>
  );
}
