import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { X } from 'lucide-react';
import type { Wallet } from '../lib/supabase';

interface SendModalProps {
  wallet: Wallet;
  onClose: () => void;
  onSuccess: () => void;
}

export default function SendModal({ wallet, onClose, onSuccess }: SendModalProps) {
  const [toAddress, setToAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const sendAmount = parseFloat(amount);

      if (sendAmount <= 0) {
        setError('Сумма должна быть больше нуля');
        return;
      }

      if (sendAmount > wallet.balance) {
        setError('Недостаточно средств');
        return;
      }

      const { error: txError } = await supabase
        .from('transactions')
        .insert({
          wallet_id: wallet.id,
          type: 'send',
          amount: sendAmount,
          currency: wallet.currency,
          to_address: toAddress,
          from_address: wallet.address,
          status: 'completed',
          completed_at: new Date().toISOString()
        });

      if (txError) throw txError;

      const { error: updateError } = await supabase
        .from('wallets')
        .update({ balance: wallet.balance - sendAmount })
        .eq('id', wallet.id);

      if (updateError) throw updateError;

      onSuccess();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-800">
            Отправить {wallet.currency}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="bg-blue-50 p-4 rounded-xl mb-6">
          <p className="text-sm text-gray-600 mb-1">Доступно</p>
          <p className="text-2xl font-bold text-gray-800">
            {wallet.balance} {wallet.currency}
          </p>
        </div>

        <form onSubmit={handleSend} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Адрес получателя
            </label>
            <input
              type="text"
              value={toAddress}
              onChange={(e) => setToAddress(e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
              placeholder="0x..."
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Сумма
            </label>
            <input
              type="number"
              step="0.00000001"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
              placeholder="0.00"
              required
            />
          </div>

          {error && (
            <div className="bg-red-50 text-red-600 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          <div className="flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition font-medium"
            >
              Отмена
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-4 py-3 bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-lg hover:from-blue-600 hover:to-cyan-600 transition font-semibold disabled:opacity-50"
            >
              {loading ? 'Отправка...' : 'Отправить'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
